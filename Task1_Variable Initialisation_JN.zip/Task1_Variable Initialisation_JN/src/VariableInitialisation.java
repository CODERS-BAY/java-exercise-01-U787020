public class VariableInitialisation {
    public static void main(String[] args) {

        String firstName = "Julia";
        String lastName  = "Nusko";
        int age = 42;
        String address = "Auerspergstraße 23, Linz";
        int postalCode = 4020;
        boolean married = false;
        double salary = 123.45;

        System.out.println(firstName);
        System.out.println(lastName);
        System.out.println(age);
        System.out.println(address);
        System.out.println(postalCode);
        System.out.println(married);
        System.out.println(salary);
    }
}
